/**
 * DateObject interface.
 *
 */
public interface DateObject extends java.rmi.Remote
{
	public void setDate(java.util.Date date) throws java.rmi.RemoteException;
}
